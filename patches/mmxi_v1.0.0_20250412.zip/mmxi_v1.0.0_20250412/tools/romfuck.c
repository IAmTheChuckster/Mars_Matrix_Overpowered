// gcc romfuck.c -o romfuck
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

//-------------------------------------------------------------------------------------------------
size_t file_load(uint8_t **obuf, const char *name) {
  FILE *ifp = fopen(name, "rb");
  fseek(ifp, 0, SEEK_END);
  size_t size = ftell(ifp);
  fseek(ifp, 0, SEEK_SET);
  *obuf = calloc(1, size);
  fread(*obuf, size, 1, ifp);
  fclose(ifp);
  return size;
}

//-------------------------------------------------------------------------------------------------
int main(int argc, const char *argv[]) {
  int mode = 0;
  if(strcmp(argv[1], "s") == 0) {
    mode = 0;
  }else if(strcmp(argv[1], "x") == 0) {
    mode = 1;
  }else if(strcmp(argv[1], "z") == 0) {
    mode = 2;
  }else if(strcmp(argv[1], "Z") == 0) {
    mode = 3;
  }else{
    fprintf(stderr, "fuck off\n");
    fflush(stderr);
    return 1;
  }

  switch(mode) {
    case 0: { // byte swap
      uint8_t *srcbuf;
      size_t srcsize = file_load(&srcbuf, argv[3]);
      for(int i = 0; i < srcsize; i += 2) {
        uint8_t tmp = srcbuf[i + 0];
        srcbuf[i + 0] = srcbuf[i + 1];
        srcbuf[i + 1] = tmp;
      }
      FILE *ofp = fopen(argv[2], "wb");
      fwrite(srcbuf, srcsize, 1, ofp);
      fclose(ofp);
      break;
    }
    case 1: { // split for output
      uint8_t *srcbuf;
      size_t srcsize = file_load(&srcbuf, argv[argc-1]);
      size_t off = 0;
      size_t split_size = srcsize / 3;
      for(int i = 0; i < 3; i++) {
        FILE *ofp = fopen(argv[2+i], "wb");
        fwrite(srcbuf + off, split_size, 1, ofp);
        fclose(ofp);
        off += split_size;
      }
      break;
    }
    case 2: { // z80 slice
      uint8_t *srcbuf;
      size_t srcsize = file_load(&srcbuf, argv[3]);
      FILE *ofp = fopen(argv[2], "wb");
      size_t len = strtol(argv[4], NULL, 0);
      fwrite(srcbuf, len, 1, ofp);
      fclose(ofp);
      break;
    }
    case 3: { // z80 insert
      uint8_t *newbuf;
      size_t newsize = file_load(&newbuf, argv[3]);
      uint8_t *origbuf;
      size_t origsize = file_load(&origbuf, argv[4]);
      FILE *ofp = fopen(argv[2], "wb");
      fwrite(newbuf, newsize, 1, ofp);
      fwrite(origbuf+newsize, origsize-newsize, 1, ofp);
      fclose(ofp);
      break;
    }
  }
}

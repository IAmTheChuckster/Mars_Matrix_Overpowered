#!/bin/sh
if [ -z "$SETNAME" ]; then
	SETNAME=mmxj
fi

gcc -DBUILD_DECRYPTOR tools/common.c -o tools/decrypt
gcc -DBUILD_ENCRYPTOR tools/common.c -o tools/encrypt
gcc -DBUILD_ENCRYPTOR tools/romfuck.c -o tools/romfuck

rm -rf build
mkdir -p build
mkdir -p output

./tools/decrypt build/dec.03 orig/$SETNAME.03 orig/$SETNAME.key 0x000000
./tools/decrypt build/dec.04 orig/$SETNAME.04 orig/$SETNAME.key 0x080000
./tools/decrypt build/dec.05 orig/$SETNAME.05 orig/$SETNAME.key 0x100000

cat build/dec.03 build/dec.04 build/dec.05 > build/decrypted.bin
./tools/romfuck z build/z80_in.bin orig/$SETNAME.01 0x8000
./tools/romfuck s build/code_in.bin build/decrypted.bin

./tools/as/bin/asw src/patch.asm -D PATCH_CODE -i . -n -U -L -olist build/code.lst -o build/code.obj
./tools/as/bin/p2bin build/code.obj build/code_out.bin -r 0x000000-0x17FFFF

./tools/romfuck s build/code_out_prep.bin build/code_out.bin
./tools/encrypt build/encrypted.bin build/code_out_prep.bin orig/$SETNAME.key 0x000000
./tools/romfuck s build/data_in.bin build/encrypted.bin

./tools/as/bin/asw src/patch.asm -D PATCH_DATA -i . -n -U -L -olist build/data.lst -o build/data.obj
./tools/as/bin/p2bin build/data.obj build/data_out.bin -r 0x000000-0x17FFFF

./tools/as/bin/asw src/patch_z80.asm -D PATCH_Z80 -i . -n -U -L -olist build/z80.lst -o build/z80.obj
./tools/as/bin/p2bin build/z80.obj build/z80_out.bin -r 0x000000-0x7FFF

./tools/romfuck s build/final.bin build/data_out.bin
./tools/romfuck Z build/final_z80.bin build/z80_out.bin orig/$SETNAME.01
cp build/final_z80.bin output/$SETNAME.01
./tools/romfuck x output/$SETNAME.03 output/$SETNAME.04 output/$SETNAME.05 build/final.bin
cp orig/$SETNAME.key output/$SETNAME.key

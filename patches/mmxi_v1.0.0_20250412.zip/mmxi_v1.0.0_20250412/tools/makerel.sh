#!/bin/sh
if [ -z "$XDELTA3" ]; then
	XDELTA3=tools/xdelta3-3_0_11/xdelta3-3.0.11-x86_64.exe
fi

rm -rf output/

SETNAME=mmxu . ./tools/patch.sh
SETNAME=mmxj . ./tools/patch.sh

rm -rf rel/
mkdir -p rel/
${XDELTA3} -f -A= -s output/mmxj.03 orig/mmxj.03 rel/mmxj.03.xdelta3
${XDELTA3} -f -A= -s output/mmxj.04 orig/mmxj.04 rel/mmxj.04.xdelta3
${XDELTA3} -f -A= -s output/mmxj.05 orig/mmxj.05 rel/mmxj.05.xdelta3

${XDELTA3} -f -A= -s output/mmxu.03 orig/mmxu.03 rel/mmxu.03.xdelta3
${XDELTA3} -f -A= -s output/mmxu.04 orig/mmxu.04 rel/mmxu.04.xdelta3
${XDELTA3} -f -A= -s output/mmxu.05 orig/mmxu.05 rel/mmxu.05.xdelta3

${XDELTA3} -f -A= -s output/mmxj.01 orig/mmxj.01 rel/mmx.01.xdelta3

cp -r src/ rel/src/
cp -r tools/ rel/tools/
cp image.png rel/
cp README.md rel/

// Derived from the great source at https://github.com/mamedev/mame/blob/master/src/mame/capcom/cps2crypt.cpp

// gcc -DBUILD_DECRYPTOR common.c -o decrypt
// gcc -DBUILD_ENCRYPTOR common.c -o encrypt
// ./decrypt dec.03 mmxu.03 mmatrix.key 0x000000
// ./decrypt dec.04 mmxu.04 mmatrix.key 0x080000
// ./decrypt dec.05 mmxu.05 mmatrix.key 0x100000
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

//-------------------------------------------------------------------------------------------------
typedef struct {
  uint32_t key[2];
  uint32_t upper, lower;
} Cps2Key;

typedef struct {
  uint8_t table[64];
  int inputs[6];
  int outputs[2];
} SBox;

typedef struct {
  const SBox *sbox;
  uint8_t input_lut[256];
  uint8_t output[64];
} SBoxOptimize;

//-------------------------------------------------------------------------------------------------
const int fn1_groupA[8] = { 10, 4, 6, 7, 2, 13, 15, 14 };
const int fn1_groupB[8] = {  0, 1, 3, 5, 8,  9, 11, 12 };

const int fn2_groupA[8] = { 6, 0, 2, 13, 1,  4, 14,  7 };
const int fn2_groupB[8] = { 3, 5, 9, 10, 8, 15, 12, 11 };

const SBox fn1_r1_boxes[4] =
{
  {   // subkey bits  0- 5
    {
      0,2,2,0,1,0,1,1,3,2,0,3,0,3,1,2,1,1,1,2,1,3,2,2,2,3,3,2,1,1,1,2,
      2,2,0,0,3,1,3,1,1,1,3,0,0,1,0,0,1,2,2,1,2,3,2,2,2,3,1,3,2,0,1,3,
    },
    { 3, 4, 5, 6, -1, -1 },
    { 3, 6 }
  },
  {   // subkey bits  6-11
    {
      3,0,2,2,2,1,1,1,1,2,1,0,0,0,2,3,2,3,1,3,0,0,0,2,1,2,2,3,0,3,3,3,
      0,1,3,2,3,3,3,1,1,1,1,2,0,1,2,1,3,2,3,1,1,3,2,2,2,3,1,3,2,3,0,0,
    },
    { 0, 1, 2, 4, 7, -1 },
    { 2, 7 }
  },
  {   // subkey bits 12-17
    {
      3,0,3,1,1,0,2,2,3,1,2,0,3,3,2,3,0,1,0,1,2,3,0,2,0,2,0,1,0,0,1,0,
      2,3,1,2,1,0,2,0,2,1,0,1,0,2,1,0,3,1,2,3,1,3,1,1,1,2,0,2,2,0,0,0,
    },
    { 0, 1, 2, 3, 6, 7 },
    { 0, 1 }
  },
  {   // subkey bits 18-23
    {
      3,2,0,3,0,2,2,1,1,2,3,2,1,3,2,1,2,2,1,3,3,2,1,0,1,0,1,3,0,0,0,2,
      2,1,0,1,0,1,0,1,3,1,1,2,2,3,2,0,3,3,2,0,2,1,3,3,0,0,3,0,1,1,3,3,
    },
    { 0, 1, 3, 5, 6, 7 },
    { 4, 5 }
  },
};

const SBox fn1_r2_boxes[4] =
{
  {   // subkey bits 24-29
    {
      3,3,2,0,3,0,3,1,0,3,0,1,0,2,1,3,1,3,0,3,3,1,3,3,3,2,3,2,2,3,1,2,
      0,2,2,1,0,1,2,0,3,3,0,1,3,2,1,2,3,0,1,3,0,1,2,2,1,2,1,2,0,1,3,0,
    },
    { 0, 1, 2, 3, 6, -1 },
    { 1, 6 }
  },
  {   // subkey bits 30-35
    {
      1,2,3,2,1,3,0,1,1,0,2,0,0,2,3,2,3,3,0,1,2,2,1,0,1,0,1,2,3,2,1,3,
      2,2,2,0,1,0,2,3,2,1,2,1,2,1,0,3,0,1,2,3,1,2,1,3,2,0,3,2,3,0,2,0,
    },
    { 2, 4, 5, 6, 7, -1 },
    { 5, 7 }
  },
  {   // subkey bits 36-41
    {
      0,1,0,2,1,1,0,1,0,2,2,2,1,3,0,0,1,1,3,1,2,2,2,3,1,0,3,3,3,2,2,2,
      1,1,3,0,3,1,3,0,1,3,3,2,1,1,0,0,1,2,2,2,1,1,1,2,2,0,0,3,2,3,1,3,
    },
    { 1, 2, 3, 4, 5, 7 },
    { 0, 3 }
  },
  {   // subkey bits 42-47
    {
      2,1,0,3,3,3,2,0,1,2,1,1,1,0,3,1,1,3,3,0,1,2,1,0,0,0,3,0,3,0,3,0,
      1,3,3,3,0,3,2,0,2,1,2,2,2,1,1,3,0,1,0,1,0,1,1,1,1,3,1,0,1,2,3,3,
    },
    { 0, 1, 3, 4, 6, 7 },
    { 2, 4 }
  },
};

const SBox fn1_r3_boxes[4] =
{
  {   // subkey bits 48-53
    {
      0,0,0,3,3,1,1,0,2,0,2,0,0,0,3,2,0,1,2,3,2,2,1,0,3,0,0,0,0,0,2,3,
      3,0,0,1,1,2,3,3,0,1,3,2,0,1,3,3,2,0,0,1,0,2,0,0,0,3,1,3,3,3,3,3,
    },
    { 0, 1, 5, 6, 7, -1 },
    { 0, 5 }
  },
  {   // subkey bits 54-59
    {
      2,3,2,3,0,2,3,0,2,2,3,0,3,2,0,2,1,0,2,3,1,1,1,0,0,1,0,2,1,2,2,1,
      3,0,2,1,2,3,3,0,3,2,3,1,0,2,1,0,1,2,2,3,0,2,1,3,1,3,0,2,1,1,1,3,
    },
    { 2, 3, 4, 6, 7, -1 },
    { 6, 7 }
  },
  {   // subkey bits 60-65
    {
      3,0,2,1,1,3,1,2,2,1,2,2,2,0,0,1,2,3,1,0,2,0,0,2,3,1,2,0,0,0,3,0,
      2,1,1,2,0,0,1,2,3,1,1,2,0,1,3,0,3,1,1,0,0,2,3,0,0,0,0,3,2,0,0,0,
    },
    { 0, 2, 3, 4, 5, 6 },
    { 1, 4 }
  },
  {   // subkey bits 66-71
    {
      0,1,0,0,2,1,3,2,3,3,2,1,0,1,1,1,1,1,0,3,3,1,1,0,0,2,2,1,0,3,3,2,
      1,3,3,0,3,0,2,1,1,2,3,2,2,2,1,0,0,3,3,3,2,2,3,1,0,2,3,0,3,1,1,0,
    },
    { 0, 1, 2, 3, 5, 7 },
    { 2, 3 }
  },
};

const SBox fn1_r4_boxes[4] =
{
  {   // subkey bits 72-77
    {
      1,1,1,1,1,0,1,3,3,2,3,0,1,2,0,2,3,3,0,1,2,1,2,3,0,3,2,3,2,0,1,2,
      0,1,0,3,2,1,3,2,3,1,2,3,2,0,1,2,2,0,0,0,2,1,3,0,3,1,3,0,1,3,3,0,
    },
    { 1, 2, 3, 4, 5, 7 },
    { 0, 4 }
  },
  {   // subkey bits 78-83
    {
      3,0,0,0,0,1,0,2,3,3,1,3,0,3,1,2,2,2,3,1,0,0,2,0,1,0,2,2,3,3,0,0,
      1,1,3,0,2,3,0,3,0,3,0,2,0,2,0,1,0,3,0,1,3,1,1,0,0,1,3,3,2,2,1,0,
    },
    { 0, 1, 2, 3, 5, 6 },
    { 1, 3 }
  },
  {   // subkey bits 84-89
    {
      0,1,1,2,0,1,3,1,2,0,3,2,0,0,3,0,3,0,1,2,2,3,3,2,3,2,0,1,0,0,1,0,
      3,0,2,3,0,2,2,2,1,1,0,2,2,0,0,1,2,1,1,1,2,3,0,3,1,2,3,3,1,1,3,0,
    },
    { 0, 2, 4, 5, 6, 7 },
    { 2, 6 }
  },
  {   // subkey bits 90-95
    {
      0,1,2,2,0,1,0,3,2,2,1,1,3,2,0,2,0,1,3,3,0,2,2,3,3,2,0,0,2,1,3,3,
      1,1,1,3,1,2,1,1,0,3,3,2,3,2,3,0,3,1,0,0,3,0,0,0,2,2,2,1,2,3,0,0,
    },
    { 0, 1, 3, 4, 6, 7 },
    { 5, 7 }
  },
};

/******************************************************************************/
const SBox fn2_r1_boxes[4] =
{
  {   // subkey bits  0- 5
    {
      2,0,2,0,3,0,0,3,1,1,0,1,3,2,0,1,2,0,1,2,0,2,0,2,2,2,3,0,2,1,3,0,
      0,1,0,1,2,2,3,3,0,3,0,2,3,0,1,2,1,1,0,2,0,3,1,1,2,2,1,3,1,1,3,1,
    },
    { 0, 3, 4, 5, 7, -1 },
    { 6, 7 }
  },
  {   // subkey bits  6-11
    {
      1,1,0,3,0,2,0,1,3,0,2,0,1,1,0,0,1,3,2,2,0,2,2,2,2,0,1,3,3,3,1,1,
      1,3,1,3,2,2,2,2,2,2,0,1,0,1,1,2,3,1,1,2,0,3,3,3,2,2,3,1,1,1,3,0,
    },
    { 1, 2, 3, 4, 6, -1 },
    { 3, 5 }
  },
  {   // subkey bits 12-17
    {
      1,0,2,2,3,3,3,3,1,2,2,1,0,1,2,1,1,2,3,1,2,0,0,1,2,3,1,2,0,0,0,2,
      2,0,1,1,0,0,2,0,0,0,2,3,2,3,0,1,3,0,0,0,2,3,2,0,1,3,2,1,3,1,1,3,
    },
    { 1, 2, 4, 5, 6, 7 },
    { 1, 4 }
  },
  {   // subkey bits 18-23
    {
      1,3,3,0,3,2,3,1,3,2,1,1,3,3,2,1,2,3,0,3,1,0,0,2,3,0,0,0,3,3,0,1,
      2,3,0,0,0,1,2,1,3,0,0,1,0,2,2,2,3,3,1,2,1,3,0,0,0,3,0,1,3,2,2,0,
    },
    { 0, 2, 3, 5, 6, 7 },
    { 0, 2 }
  },
};

const SBox fn2_r2_boxes[4] =
{
  {   // subkey bits 24-29
    {
      3,1,3,0,3,0,3,1,3,0,0,1,1,3,0,3,1,1,0,1,2,3,2,3,3,1,2,2,2,0,2,3,
      2,2,2,1,1,3,3,0,3,1,2,1,1,1,0,2,0,3,3,0,0,2,0,0,1,1,2,1,2,1,1,0,
    },
    { 0, 2, 4, 6, -1, -1 },
    { 4, 6 }
  },
  {   // subkey bits 30-35
    {
      0,3,0,3,3,2,1,2,3,1,1,1,2,0,2,3,0,3,1,2,2,1,3,3,3,2,1,2,2,0,1,0,
      2,3,0,1,2,0,1,1,2,0,2,1,2,0,2,3,3,1,0,2,3,3,0,3,1,1,3,0,0,1,2,0,
    },
    { 1, 3, 4, 5, 6, 7 },
    { 0, 3 }
  },
  {   // subkey bits 36-41
    {
      0,0,2,1,3,2,1,0,1,2,2,2,1,1,0,3,1,2,2,3,2,1,1,0,3,0,0,1,1,2,3,1,
      3,3,2,2,1,0,1,1,1,2,0,1,2,3,0,3,3,0,3,2,2,0,2,2,1,2,3,2,1,0,2,1,
    },
    { 0, 1, 3, 4, 5, 7 },
    { 1, 7 }
  },
  {   // subkey bits 42-47
    {
      0,2,1,2,0,2,2,0,1,3,2,0,3,2,3,0,3,3,2,3,1,2,3,1,2,2,0,0,2,2,1,2,
      2,3,3,3,1,1,0,0,0,3,2,0,3,2,3,1,1,1,1,0,1,0,1,3,0,0,1,2,2,3,2,0,
    },
    { 1, 2, 3, 5, 6, 7 },
    { 2, 5 }
  },
};

const SBox fn2_r3_boxes[4] =
{
  {   // subkey bits 48-53
    {
      2,1,2,1,2,3,1,3,2,2,1,3,3,0,0,1,0,2,0,3,3,1,0,0,1,1,0,2,3,2,1,2,
      1,1,2,1,1,3,2,2,0,2,2,3,3,3,2,0,0,0,0,0,3,3,3,0,1,2,1,0,2,3,3,1,
    },
    { 2, 3, 4, 6, -1, -1 },
    { 3, 5 }
  },
  {   // subkey bits 54-59
    {
      3,2,3,3,1,0,3,0,2,0,1,1,1,0,3,0,3,1,3,1,0,1,2,3,2,2,3,2,0,1,1,2,
      3,0,0,2,1,0,0,2,2,0,1,0,0,2,0,0,1,3,1,3,2,0,3,3,1,0,2,2,2,3,0,0,
    },
    { 0, 1, 3, 5, 7, -1 },
    { 0, 2 }
  },
  {   // subkey bits 60-65
    {
      2,2,1,0,2,3,3,0,0,0,1,3,1,2,3,2,2,3,1,3,0,3,0,3,3,2,2,1,0,0,0,2,
      1,2,2,2,0,0,1,2,0,1,3,0,2,3,2,1,3,2,2,2,3,1,3,0,2,0,2,1,0,3,3,1,
    },
    { 0, 1, 2, 3, 5, 7 },
    { 1, 6 }
  },
  {   // subkey bits 66-71
    {
      1,2,3,2,0,2,1,3,3,1,0,1,1,2,2,0,0,1,1,1,2,1,1,2,0,1,3,3,1,1,1,2,
      3,3,1,0,2,1,1,1,2,1,0,0,2,2,3,2,3,2,2,0,2,2,3,3,0,2,3,0,2,2,1,1,
    },
    { 0, 2, 4, 5, 6, 7 },
    { 4, 7 }
  },
};

const SBox fn2_r4_boxes[4] =
{
  {   // subkey bits 72-77
    {
      2,0,1,1,2,1,3,3,1,1,1,2,0,1,0,2,0,1,2,0,2,3,0,2,3,3,2,2,3,2,0,1,
      3,0,2,0,2,3,1,3,2,0,0,1,1,2,3,1,1,1,0,1,2,0,3,3,1,1,1,3,3,1,1,0,
    },
    { 0, 1, 3, 6, 7, -1 },
    { 0, 3 }
  },
  {   // subkey bits 78-83
    {
      1,2,2,1,0,3,3,1,0,2,2,2,1,0,1,0,1,1,0,1,0,2,1,0,2,1,0,2,3,2,3,3,
      2,2,1,2,2,3,1,3,3,3,0,1,0,1,3,0,0,0,1,2,0,3,3,2,3,2,1,3,2,1,0,2,
    },
    { 0, 1, 2, 4, 5, 6 },
    { 4, 7 }
  },
  {   // subkey bits 84-89
    {
      2,3,2,1,3,2,3,0,0,2,1,1,0,0,3,2,3,1,0,1,2,2,2,1,3,2,2,1,0,2,1,2,
      0,3,1,0,0,3,1,1,3,3,2,0,1,0,1,3,0,0,1,2,1,2,3,2,1,0,0,3,2,1,1,3,
    },
    { 0, 2, 3, 4, 5, 7 },
    { 1, 2 }
  },
  {   // subkey bits 90-95
    {
      2,0,0,3,2,2,2,1,3,3,1,1,2,0,0,3,1,0,3,2,1,0,2,0,3,2,2,3,2,0,3,0,
      1,3,0,2,2,1,3,3,0,1,0,3,1,1,3,2,0,3,0,2,3,2,1,3,2,3,0,0,1,3,2,1,
    },
    { 2, 3, 4, 5, 6, 7 },
    { 5, 6 }
  },
};

//-------------------------------------------------------------------------------------------------
static uint32_t sbox_input_extract(const SBox *sbox, uint32_t val) {
  uint32_t res = 0;
  for(int i = 0; i < 6; i++) {
    if(sbox->inputs[i] >= 0) {
      res |= ((val >> sbox->inputs[i]) & 1) << i;
    }
  }
  return res;
}

static void sbox_optimize(SBoxOptimize *dst, const SBox *sbox) {
  dst->sbox = sbox;
  // precalculate input lookup
  for(int i = 0; i < 256; i++) {
    dst->input_lut[i] = sbox_input_extract(sbox, i);
  }
  // precalculate output masks
  for(int i = 0; i < 64; i++) {
    uint8_t val = 0;
    if(sbox->table[i] & 1) val |= 1 << sbox->outputs[0];
    if(sbox->table[i] & 2) val |= 1 << sbox->outputs[1];
    dst->output[i] = val;
  }
}

static uint8_t optsbox_exec(const SBoxOptimize *sbox, uint8_t val, uint32_t key) {
  return sbox->output[sbox->input_lut[val] ^ (key & 0x3F)];
}

static void sboxgang_optimize(SBoxOptimize *dst, const SBox *src) {
  for(int i = 0; i < 4; i++) {
    sbox_optimize(&dst[i], &src[i]);
  }
}

static uint8_t sboxgang_exec(const SBoxOptimize *sboxen, uint8_t value, uint32_t key) {
  return optsbox_exec(&sboxen[0], value, key >> 0) |
         optsbox_exec(&sboxen[1], value, key >> 6) |
         optsbox_exec(&sboxen[2], value, key >>12) |
         optsbox_exec(&sboxen[3], value, key >>18);
}

//-------------------------------------------------------------------------------------------------
static void key_expansion(uint32_t *dstkey, const uint32_t *srckey, const uint8_t *bits) {
  dstkey[0] = 0;
  dstkey[1] = 0;
  dstkey[2] = 0;
  dstkey[3] = 0;

  for (int i = 0; i < 96; ++i) {
    dstkey[i / 24] |= ((srckey[bits[i] / 32] >> (bits[i] % 32)) & 1) << (i % 24);
  }
}

// srckey is the 64-bit master key (2x32 bits)
// dstkey will contain the 96-bit key for the 1st FN (4x24 bits)
void expand_1st_key(uint32_t *dstkey, const uint32_t *srckey) {
  static const uint8_t bits[96] = {
    33, 58, 49, 36,  0, 31,
    22, 30,  3, 16,  5, 53,
    10, 41, 23, 19, 27, 39,
    43,  6, 34, 12, 61, 21,
    48, 13, 32, 35,  6, 42,
    43, 14, 21, 41, 52, 25,
    18, 47, 46, 37, 57, 53,
    20,  8, 55, 54, 59, 60,
    27, 33, 35, 18,  8, 15,
    63,  1, 50, 44, 16, 46,
     5,  4, 45, 51, 38, 25,
    13, 11, 62, 29, 48,  2,
    59, 61, 62, 56, 51, 57,
    54,  9, 24, 63, 22,  7,
    26, 42, 45, 40, 23, 14,
     2, 31, 52, 28, 44, 17,
  };

  key_expansion(dstkey, srckey, bits);
}

// srckey is the 64-bit master key (2x32 bits) XORed with the subkey
// dstkey will contain the 96-bit key for the 2nd FN (4x24 bits)
void expand_2nd_key(uint32_t *dstkey, const uint32_t *srckey) {
  static const uint8_t bits[96] = {
    34,  9, 32, 24, 44, 54,
    38, 61, 47, 13, 28,  7,
    29, 58, 18,  1, 20, 60,
    15,  6, 11, 43, 39, 19,
    63, 23, 16, 62, 54, 40,
    31,  3, 56, 61, 17, 25,
    47, 38, 55, 57,  5,  4,
    15, 42, 22,  7,  2, 19,
    46, 37, 29, 39, 12, 30,
    49, 57, 31, 41, 26, 27,
    24, 36, 11, 63, 33, 16,
    56, 62, 48, 60, 59, 32,
    12, 30, 53, 48, 10,  0,
    50, 35,  3, 59, 14, 49,
    51, 45, 44,  2, 21, 33,
    55, 52, 23, 28,  8, 26,
  };

  key_expansion(dstkey, srckey, bits);
}

// seed is the 16-bit seed generated by the first FN
// subkey will contain the 64-bit key to be XORed with the master key
// for the 2nd FN (2x32 bits)
void expand_subkey(uint32_t *subkey, uint16_t seed) {
  // Note that each row of the table is a permutation of the seed bits.
  static const uint8_t bits[64] = {
     5, 10, 14,  9,  4,  0, 15,  6,  1,  8,  3,  2, 12,  7, 13, 11,
     5, 12,  7,  2, 13, 11,  9, 14,  4,  1,  6, 10,  8,  0, 15,  3,
     4, 10,  2,  0,  6,  9, 12,  1, 11,  7, 15,  8, 13,  5, 14,  3,
    14, 11, 12,  7,  4,  5,  2, 10,  1, 15,  0,  9,  8,  6, 13,  3,
  };

  subkey[0] = 0;
  subkey[1] = 0;

  for (int i = 0; i < 64; ++i)
    subkey[i / 32] |= ((seed >> bits[i]) & 1) << (i % 32);
}

//-------------------------------------------------------------------------------------------------
static uint8_t bitswap8(uint32_t val, const int *bits) {
  uint8_t outval = 0;
  for(int i = 0; i < 8; i++) {
    if(val & (1 << bits[i])) outval |= 1 << i;
  }
  return outval;
}

static uint32_t bitunswap8(uint8_t val, const int *bits) {
  uint32_t outval = 0;
  for(int i = 0; i < 8; i++) {
    if(val & (1 << i)) outval |= 1 << bits[i];
  }
  return outval;
}

//-------------------------------------------------------------------------------------------------
uint16_t feistel(uint16_t val, const int *bitsA, const int *bitsB,
    const SBoxOptimize* boxes1, const SBoxOptimize* boxes2, const SBoxOptimize* boxes3, const SBoxOptimize* boxes4,
    uint32_t key1, uint32_t key2, uint32_t key3, uint32_t key4)
{
  uint8_t l = bitswap8(val, bitsB);
  uint8_t r = bitswap8(val, bitsA);

  l ^= sboxgang_exec(boxes1, r, key1);
  r ^= sboxgang_exec(boxes2, l, key2);
  l ^= sboxgang_exec(boxes3, r, key3);
  r ^= sboxgang_exec(boxes4, l, key4);

  return bitunswap8(l, bitsA) | bitunswap8(r, bitsB);
}

uint16_t unfeistel(uint16_t val, const int *bitsA, const int *bitsB,
    const SBoxOptimize* boxes1, const SBoxOptimize* boxes2, const SBoxOptimize* boxes3, const SBoxOptimize* boxes4,
    uint32_t key1, uint32_t key2, uint32_t key3, uint32_t key4)
{
  uint8_t r = bitswap8(val, bitsB);
  uint8_t l = bitswap8(val, bitsA);

  r ^= sboxgang_exec(boxes4, l, key4);
  l ^= sboxgang_exec(boxes3, r, key3);
  r ^= sboxgang_exec(boxes2, l, key2);
  l ^= sboxgang_exec(boxes1, r, key1);

  return bitunswap8(l, bitsB) | bitunswap8(r, bitsA);
}

//-------------------------------------------------------------------------------------------------
void cps2_encrypt(uint16_t *dst, const uint16_t *src, size_t srcsize, const Cps2Key *key, size_t offset) {
  offset /= 2;
  srcsize /= 2;

  SBoxOptimize sboxes1[4*4];
  sboxgang_optimize(&sboxes1[0*4], fn1_r1_boxes);
  sboxgang_optimize(&sboxes1[1*4], fn1_r2_boxes);
  sboxgang_optimize(&sboxes1[2*4], fn1_r3_boxes);
  sboxgang_optimize(&sboxes1[3*4], fn1_r4_boxes);

  SBoxOptimize sboxes2[4*4];
  sboxgang_optimize(&sboxes2[0*4], fn2_r1_boxes);
  sboxgang_optimize(&sboxes2[1*4], fn2_r2_boxes);
  sboxgang_optimize(&sboxes2[2*4], fn2_r3_boxes);
  sboxgang_optimize(&sboxes2[3*4], fn2_r4_boxes);

  // expand master key to 1st FN 96-bit key
  uint32_t key1[4];
  expand_1st_key(key1, key->key);

  // add extra bits for s-boxes with less than 6 inputs
  key1[0] ^= ((key1[0] >> 1) & 1) <<  4;
  key1[0] ^= ((key1[0] >> 2) & 1) <<  5;
  key1[0] ^= ((key1[0] >> 8) & 1) << 11;
  key1[1] ^= ((key1[1] >> 0) & 1) <<  5;
  key1[1] ^= ((key1[1] >> 8) & 1) << 11;
  key1[2] ^= ((key1[2] >> 1) & 1) <<  5;
  key1[2] ^= ((key1[2] >> 8) & 1) << 11;

  for(int i = 0; i < 0x10000; i++) {
    uint16_t seed = feistel(i, fn1_groupA, fn1_groupB,
                            &sboxes1[0*4], &sboxes1[1*4], &sboxes1[2*4], &sboxes1[3*4],
                            key1[0], key1[1], key1[2], key1[3]);
    uint32_t subkey[2];
    expand_subkey(subkey, seed);

    subkey[0] ^= key->key[0];
    subkey[1] ^= key->key[1];

    uint32_t key2[4];
    expand_2nd_key(key2, subkey);

    // add extra bits for s-boxes with less than 6 inputs
    key2[0] ^= ((key2[0] >> 0) & 1) <<  5;
    key2[0] ^= ((key2[0] >> 6) & 1) << 11;
    key2[1] ^= ((key2[1] >> 0) & 1) <<  5;
    key2[1] ^= ((key2[1] >> 1) & 1) <<  4;
    key2[2] ^= ((key2[2] >> 2) & 1) <<  5;
    key2[2] ^= ((key2[2] >> 3) & 1) <<  4;
    key2[2] ^= ((key2[2] >> 7) & 1) << 11;
    key2[3] ^= ((key2[3] >> 1) & 1) <<  5;

    for(int addr = i; addr < offset + srcsize; addr += 0x10000) {
      if(addr < offset) continue;
      if(addr < key->lower/2 || addr > key->upper/2) {
        dst[addr - offset] = src[addr - offset];
      }else{
        dst[addr - offset] = unfeistel(src[addr - offset], fn2_groupA, fn2_groupB,
                                       &sboxes2[0*4], &sboxes2[1*4], &sboxes2[2*4], &sboxes2[3*4],
                                       key2[0], key2[1], key2[2], key2[3]);
      }
    }
  }
}

//-------------------------------------------------------------------------------------------------
void cps2_decrypt(uint16_t *dst, const uint16_t *src, size_t srcsize, const Cps2Key *key, size_t offset) {
  offset /= 2;
  srcsize /= 2;

  SBoxOptimize sboxes1[4*4];
  sboxgang_optimize(&sboxes1[0*4], fn1_r1_boxes);
  sboxgang_optimize(&sboxes1[1*4], fn1_r2_boxes);
  sboxgang_optimize(&sboxes1[2*4], fn1_r3_boxes);
  sboxgang_optimize(&sboxes1[3*4], fn1_r4_boxes);

  SBoxOptimize sboxes2[4*4];
  sboxgang_optimize(&sboxes2[0*4], fn2_r1_boxes);
  sboxgang_optimize(&sboxes2[1*4], fn2_r2_boxes);
  sboxgang_optimize(&sboxes2[2*4], fn2_r3_boxes);
  sboxgang_optimize(&sboxes2[3*4], fn2_r4_boxes);

  // expand master key to 1st FN 96-bit key
  uint32_t key1[4];
  expand_1st_key(key1, key->key);

  // add extra bits for s-boxes with less than 6 inputs
  key1[0] ^= ((key1[0] >> 1) & 1) <<  4;
  key1[0] ^= ((key1[0] >> 2) & 1) <<  5;
  key1[0] ^= ((key1[0] >> 8) & 1) << 11;
  key1[1] ^= ((key1[1] >> 0) & 1) <<  5;
  key1[1] ^= ((key1[1] >> 8) & 1) << 11;
  key1[2] ^= ((key1[2] >> 1) & 1) <<  5;
  key1[2] ^= ((key1[2] >> 8) & 1) << 11;

  for(int i = 0; i < 0x10000; i++) {
    uint16_t seed = feistel(i, fn1_groupA, fn1_groupB,
                            &sboxes1[0*4], &sboxes1[1*4], &sboxes1[2*4], &sboxes1[3*4],
                            key1[0], key1[1], key1[2], key1[3]);
    uint32_t subkey[2];
    expand_subkey(subkey, seed);

    subkey[0] ^= key->key[0];
    subkey[1] ^= key->key[1];

    uint32_t key2[4];
    expand_2nd_key(key2, subkey);

    // add extra bits for s-boxes with less than 6 inputs
    key2[0] ^= ((key2[0] >> 0) & 1) <<  5;
    key2[0] ^= ((key2[0] >> 6) & 1) << 11;
    key2[1] ^= ((key2[1] >> 0) & 1) <<  5;
    key2[1] ^= ((key2[1] >> 1) & 1) <<  4;
    key2[2] ^= ((key2[2] >> 2) & 1) <<  5;
    key2[2] ^= ((key2[2] >> 3) & 1) <<  4;
    key2[2] ^= ((key2[2] >> 7) & 1) << 11;
    key2[3] ^= ((key2[3] >> 1) & 1) <<  5;

    for(int addr = i; addr < offset + srcsize; addr += 0x10000) {
      if(addr < offset) continue;
      if(addr < key->lower/2 || addr > key->upper/2) {
        dst[addr - offset] = src[addr - offset];
      }else{
        dst[addr - offset] = feistel(src[addr - offset], fn2_groupA, fn2_groupB,
                                     &sboxes2[0*4], &sboxes2[1*4], &sboxes2[2*4], &sboxes2[3*4],
                                     key2[0], key2[1], key2[2], key2[3]);
      }
    }
  }
}

//-------------------------------------------------------------------------------------------------
void cps2_key_decode(Cps2Key *key, const uint8_t *src) {
  uint16_t decode[10] = {0};
  for(int i = 0; i < 10*16; i++) {
    int bit = (317 - i) % 160;
    if((src[bit>>3] << (bit & 7)) & 0x80) {
      decode[i / 16] |= 0x8000 >> (i & 15);
    }
  }

  key->key[0] = (decode[0] << 16) | decode[1];
  key->key[1] = (decode[2] << 16) | decode[3];
  if(decode[9] == 0xFFFF) {
    key->upper = 0xFFFFFF;
    key->lower = 0xFF0000;
  }else{
    key->upper = ((((~decode[9]) & 0x3FF) << 14) | 0x3FFF) + 1;
    key->lower = 0;
  }

  fprintf(stderr, "Key information:\n");
  fprintf(stderr, " KEY: %08X %08X\n", key->key[0], key->key[1]);
  fprintf(stderr, " BOUNDS: %08X~%08X\n", key->lower, key->upper);
  fflush(stderr);
}

//-------------------------------------------------------------------------------------------------
int main(int argc, const char *argv[]) {
  FILE *ifp = fopen(argv[2], "rb");
  FILE *keyfp = fopen(argv[3], "rb");
  size_t offset = strtol(argv[4], NULL, 0);
  size_t srcoffset = 0;
  size_t srclength = 0;
  if(argc > 5) {
    srcoffset = strtol(argv[5], NULL, 0);
  }
  if(argc > 6) {
    srclength = strtol(argv[6], NULL, 0);
  }

  fseek(keyfp, 0, SEEK_END);
  size_t keysize = ftell(keyfp);
  fseek(keyfp, 0, SEEK_SET);
  uint8_t *keybuf = calloc(1, keysize);
  fseek(keyfp, 0, SEEK_SET);
  fread(keybuf, keysize, 1, keyfp);
  fclose(keyfp);

  Cps2Key key;
  cps2_key_decode(&key, keybuf);

  fseek(ifp, 0, SEEK_END);
  size_t srcsize = ftell(ifp);
  fseek(ifp, srcoffset, SEEK_SET);
  srcsize -= srcoffset;
  if(srclength != 0) {
    srcsize = srclength;
  }
  uint8_t *srcbuf = calloc(1, srcsize);
  uint8_t *dstbuf = calloc(1, srcsize);
  fread(srcbuf, srcsize, 1, ifp);
  fclose(ifp);

#if BUILD_ENCRYPTOR
  cps2_encrypt((void*)dstbuf, (const void*)srcbuf, srcsize, &key, offset);
#elif BUILD_DECRYPTOR
  cps2_decrypt((void*)dstbuf, (const void*)srcbuf, srcsize, &key, offset);
#else
# error "Build it properly, stupid"
#endif

  FILE *ofp = fopen(argv[1], "wb");
  fwrite(dstbuf, srcsize, 1, ofp);
  fclose(ofp);
}

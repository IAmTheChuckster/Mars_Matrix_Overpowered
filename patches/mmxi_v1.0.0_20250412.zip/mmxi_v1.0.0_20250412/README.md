# Mars Matrix Improvement v1.0.0

Planned and developed by Alex "trap15" Marshall in 2025. Released on 25th anniversary.

email: <trap15@raidenii.net> | web: <http://daifukkat.su/> | twitter: @trap0xf

Official website: <http://daifukkat.su/hacks/mmatrx/>

Source code: <http://bitbucket.org/trap15/mmatrix_unfuck/>


# About

This patch removes 2 frames of input lag, and adds several quality of life improvements:

- Pressing ABC+Start will reset the game from any point.
- Resetting the game either with the above soft-reset or by entering the test menu, will no longer reset the score table.
- Button B is a rapid-cannon button, firing the cannon at the fastest possible rate.
- Button C is a rapid-fire button, firing the rapid shot at the fastest possible rate.
- Sound effect volume is significantly reduced. When pressing start, holding A will use the original volume.
- Initial version and legal screens can be skipped with start or coin, instead of only A.


# Patch files

In addition to the below patching process information, you can build patched files directly by compiling the patch from the included source code.

## ROM patches

The patches included here are for ORIGINAL, ENCRYPTED ROM images.

Apply the included XDELTA patches manually. Use the mmxj patches for Japan version, or mmxu patches for USA version. mmx.01.xdelta3 applies to both versions equally.


# Build requirements

I have included all of the build tools, pre-built for Windows.


# History, etc.

* v1.0.0 - 20250412 - Public release
    - First full public release

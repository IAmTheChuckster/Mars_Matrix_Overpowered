	CPU		Z80
	dottedstructs	on

	ORG	0
	BINCLUDE build/z80_in.bin

LAST_ORG	:= 7000h
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Hop to our volume adjuster
	ORG	01FECh
	ld	A,(IX+1)	; Non-zero if it's a sound effect. convenient!
	and	A
	call	volume_writer
	nop

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Volume patcher
	ORG	LAST_ORG
volume_writer:
	jr	z,.no_cut
	ld	A,(0C010h)	; Our 'setting' flag
	and	A
	jr	nz,.no_cut

	push	DE
	ld	D,H
	ld	E,L
	srl	D
	rr	E
	and	A
	sbc	HL,DE
	srl	D
	rr	E
	srl	D
	rr	E
	srl	D
	rr	E
	add	HL,DE
	pop	DE

.no_cut:
	ld	A,L
	ld	(0D001h),A
	ld	A,H
	ld	(0D000h),A
	ret

	CPU		68000
	dottedstructs	on
	PADDING	OFF

	IFNDEF PATCH_CODE
PATCH_CODE	:= 0
	ENDIF

	IFNDEF PATCH_DATA
PATCH_DATA	:= 0
	ENDIF

	ORG	0
	IF PATCH_CODE
	BINCLUDE build/code_in.bin
	ELSEIF PATCH_DATA
	BINCLUDE build/data_in.bin
	ENDIF

v_inp_p1_now	:= $FFB074
v_inp_p2_now	:= $FFB076
v_dswA		:= $FFB078
v_inp_p1_prev	:= $FFB07C
v_inp_p2_prev	:= $FFB07E
v_inp_p1_held	:= $FFB080
v_inp_p2_held	:= $FFB084
HW__IO__IN0	:= $804000
HW__IO__IN2	:= $804020
HW__IO__DSWA	:= $8040B0

vsync_wait	:= $151D76
obj_update	:= $152CE6

LAST_ORG	:= $17FE00

	IF PATCH_CODE
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Adjust the stack for free RAM
	ORG	$14F9B2
	lea	($00FFFFF0).l,SP

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Fix fucking input lag
	ORG	$119B9E
	jsr	vsync_wait
	jsr	hw_input_read
	jsr	obj_update

	ORG	$119C00
	jsr	vsync_wait
	jsr	hw_input_read

	ORG	$1543AE
	jsr	hw_input_read
	jsr	(A3)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Add cool internal autofire behavior
; A = normal single button
; B = rapid cannon
; C/D = full auto
; Prioritize A > B > C/D
; Button press timing is tracked across all buttons properly.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	ORG	$15204A
hw_input_read:
	movem.l	D0-D3/A0-A2,-(SP)

	move.l	(HW__IO__DSWA).l,(v_dswA).l

	move.w	(HW__IO__IN2).l,D0
	ori.w	#$F8,D0
	ror.b	#3,D0

	move.b	(HW__IO__IN0+1).l,D1
	lea	($FFFFFC).l,A0
	lea	(v_inp_p1_now).l,A1
	lea	(v_inp_p1_held).l,A2
	move.w	#$C,D3
	jsr	inpone_proc

	move.b	(HW__IO__IN0).l,D1
	addq.w	#2,A0
	addq.w	#2,A1
	addq.w	#4,A2
	addq.w	#1+4,D3
	jsr	inpone_proc

	movem.l	(SP)+,D0-D3/A0-A2
	rts

	ORG	LAST_ORG
inpone_proc:
	lsl.w	#8,D1
	move.b	D0,D1
	rol.w	#8,D1

	btst	D3,D0
	bne.s	.no_coin
	bclr	#$C,D1
.no_coin:
	subq	#4,D3
	btst	D3,D0
	bne.s	.no_start
	bclr	#$B,D1
.no_start:
	not.w	D1

	move.w	D1,D2
	andi.w	#$FF1F,D1

	andi.w	#$08F0,D2
	cmpi.w	#$0870,D2
	bne	.no_softreset

	; Initial PC
	jmp	$14F78E

.no_softreset:
	btst	#4,D2
	bne.s	.done_btna
	btst	#5,D2
	beq.s	.try_btnc
	tst.b	(A0)
	bne.s	.done_none
	bra.s	.set_btna
.try_btnc:
	btst	#7,D2
	bne.s	.do_btnc
	btst	#6,D2
	beq.s	.done_none
.do_btnc:
	tst.b	1(A0)
	beq	.set_btna

.done_none:
	subq.b	#1,(A0)
	bcc.s	.done_btnb_waiting
	clr.b	(A0)
.done_btnb_waiting:
	clr.b	1(A0)
	bra.s	.done_end

.set_btna:
	bset	#4,D1
.done_btna:
	move.w	#(25<<8)|1,(A0)	; Minimum A press distance to get cannon

.done_end:
	move.w	D1,(A1)
	move.w	D1,D2
	and.w	8(A1),D2
	swap	D2
	move.w	D1,D2
	not.w	D1
	move.w	D1,8(A1)
	move.l	D2,(A2)
	rts

LAST_ORG := *

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Add handling for reducing SFX volume
	ORG	$153016
	jsr	sfx_value_reset_trampoline_153016

	ORG	$1605C2
	jsr	sfx_value_latch_p1_trampoline_1605C2

	ORG	$1605F0
	jsr	sfx_value_latch_p2_trampoline_1605F0

	ORG	$158592
	jsr	sfx_value_reset_trampoline_158592

	ORG	LAST_ORG
sfx_value_latch_p1_trampoline_1605C2:
	move.b	(HW__IO__IN0+1).l,D0
	bsr.s	sfx_value_latch_player
	jmp	$152232

sfx_value_latch_p2_trampoline_1605F0:
	move.b	(HW__IO__IN0).l,D0
	bsr.s	sfx_value_latch_player
	jmp	$11A398

sfx_value_latch_player:
	not.b	D0
	andi.b	#$10,D0
	lsr.b	#4,D0
	move.b	($618021).l,D1
	cmp.b	D0,D1
	ble	.doit
	move.b	D1,D0
.doit:
	move.b	D0,($618021).l
	rts

sfx_value_latch:
	move.b	(HW__IO__IN0).l,D0
	and.b	(HW__IO__IN0+1).l,D0
	andi.b	#$10,D0
.write:
	move.b	D0,($618021).l
	rts

sfx_value_reset_trampoline_153016:
	bsr.s	sfx_value_reset
	jmp	$151E5E

sfx_value_reset_trampoline_158592:
	bsr.s	sfx_value_reset
	jmp	$152142

sfx_value_reset:
	moveq	#0,D0
	bra.s	sfx_value_latch.write

LAST_ORG := *

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Better reset functionality
	ORG	$4
	dc.l	new_initial_pc

	; Move the stack here, because of NULL derefs lmao
	ORG	$14F7D0
	move.l	#$FFFFF0,SP
	ORG	$14F888
	move.l	SP,USP

	ORG	$14F90A
	jmp	memtest_check
memtest_check_return_doit := $14F916
memtest_check_return_skip := $14F930

	ORG	$119A80
	jsr	scoretbl_init_skippable

	ORG	$156A0A
	jsr	better_warning_btn_check
	btst	#$14,D0
	bne.s	$156A50

	ORG	$156A3A
	jsr	better_warning_btn_check

	ORG	$156A5A
	jsr	cookie_set_trampoline_156A5A

	ORG	$160044
	jsr	load_hiscore_proper
	nop
	nop

	ORG	LAST_ORG
new_initial_pc:
	moveq	#0,D0
	move.l	D0,($FFFFF0).l
	jmp	$14F78E

better_warning_btn_check:
	move.l	(v_inp_p1_held).l,D0
	or.l	(v_inp_p2_held).l,D0
	andi.l	#$18100000,D0
	beq.s	.zero
	move.l	#1<<20,D0
.zero:
	rts

cookie_set_trampoline_156A5A:
	move.l	#$54524150,($FFFFF0).l
	jmp	$160356

scoretbl_init_skippable:
	bsr	sfx_value_reset

	cmp.l	#$54524150,($FFFFF0).l
	beq	.skip
	jsr	$11A73A
.skip:
	rts

load_hiscore_proper:
	move.l	($FF0104+4).l,D0
	move.w	($FF0104+8).l,D1
	move.l	D0,(A0)+
	move.w	D1,(A0)+
	rts

memtest_check:
	move.l	#$FF0000,A0
	move.l	#$FFFFF0,A1

	cmp.l	#$54524150,($FFFFF0).l
	beq	.skip_test
	moveq	#0,D0
	jmp	memtest_check_return_doit
.skip_test:
	move.l	#$FF0100,A2

.loop1:
	move.l	D0,(A0)+
	move.l	D0,(A0)+
	move.l	D0,(A0)+
	move.l	D0,(A0)+
	cmpa.w	D0,A3
	cmp.w	D7,D2
	cmpa.w	A7,A5

	cmpa.l	A0,A2
	bne.s	.loop1

	move.l	#$FF0250,A0

.loop2:
	move.l	D0,(A0)+
	move.l	D0,(A0)+
	move.l	D0,(A0)+
	move.l	D0,(A0)+
	cmpa.w	D0,A3
	cmp.w	D7,D2
	cmpa.w	A7,A5

	cmpa.l	A0,A1
	bne.s	.loop2

	jmp	memtest_check_return_skip

LAST_ORG := *

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	ELSEIF PATCH_DATA
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Mark date stamp
	ORG	$156B1C
	;dc.b	"       0 0 0 4 1 2       "
	dc.b	"   00/04/12 + 25/04/12   "

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	ENDIF
